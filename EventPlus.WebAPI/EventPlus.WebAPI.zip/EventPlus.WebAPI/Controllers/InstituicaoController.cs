﻿using EventPlus.WebAPI.DTO;
using EventPlus.WebAPI.Interfaces;
using EventPlus.WebAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EventPlus.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InstituicaoController : ControllerBase
    {
        
            private readonly IInstituicao _instituicao;


            public InstituicaoController(IInstituicao instituicao)
            {
            _instituicao = instituicao;
            }

            [HttpGet("{id:guid}")]

            public async Task<IActionResult> BuscarPorId(Guid id)
            {
                var InstituicaoBuscado = await _instituicao.BuscarPorId(id);

                if (InstituicaoBuscado == null)
                return NotFound ("Tipo de Instituicao nao encontrado.");

                return Ok(InstituicaoBuscado);
            }


            [HttpGet]
            //<summary>
            //Lista todos os perfiz e usuario
            //</summary>

            public async Task<IActionResult> Listar()
            {
                try
                {
                    var tipos = await _instituicao.Listar();

                    return Ok(tipos);

                }
                catch (Exception erro)
                {
                    return BadRequest(erro.Message);
                }
            }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="dto"></param>
            /// <returns></returns>
            [HttpPost]

            public async Task<IActionResult> Cadastrar([FromBody] TipoEventoDTO dto)
            {

                var instituicao = new Instituicao
                {
                    TituloInstituicao = dto.TituloInstituicao
                };

                await _instituicao.Cadastrar(instituicao);

                return StatusCode(201, instituicao);
            }

            [HttpPut("{id:guid}")]
            public async Task<IActionResult> Atualizar(Guid id,
                [FromBody] InstituicaoDTO dto)
            {
                var instituicao = new Instituicao
                {
                    NomeFantasia = dto.NomeFantasia
                };

                await _instituicao.Atualizar(id, _instituicao);

                return Ok(_instituicao);
            }

            [HttpDelete("{id:guid}")]
            public async Task<IActionResult> Deletar(Guid id)
            {
                await _tipoEvento.Deletar(id);
                return NoContent();
            }

        }
    }
}
}
